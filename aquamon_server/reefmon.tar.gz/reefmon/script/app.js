$(function() {
  var app_url = 'http://localhost:9000/api/lighting/current';
  $('#colorsliders input').on('input', function() {
    var el = $(this);
    var colorData = {};
    colorData[el.data('color')] = el.val();
    $.ajax({
      type: 'PATCH',
      url: app_url,
      data: JSON.stringify(colorData),
      contentType: 'application/json'
    });
  });
});
